import api from './api';
import { ENDPOINTS } from '../utils/constants';

export const adminService = {
  // Documents
  getDocuments: async (statusFilter = null, sourceFilter = null) => {
    const params = {};
    if (statusFilter) params.status_filter = statusFilter;
    if (sourceFilter) params.source_filter = sourceFilter;
    
    const response = await api.get(ENDPOINTS.ADMIN_DOCUMENTS, { params });
    return response.data;
  },

  getDocumentById: async (docId) => {
    const response = await api.get(ENDPOINTS.ADMIN_DOCUMENT_BY_ID(docId));
    return response.data;
  },

  updateDocumentStatus: async (docId, status, errorMessage = null) => {
    const response = await api.put(ENDPOINTS.ADMIN_DOCUMENT_STATUS(docId), {
      status,
      error_message: errorMessage,
    });
    return response.data;
  },

  toggleDocumentActive: async (docId) => {
    const response = await api.put(ENDPOINTS.ADMIN_DOCUMENT_TOGGLE(docId));
    return response.data;
  },

  addDocument: async (docId, resourceName, pageUrl) => {
    const response = await api.post(ENDPOINTS.ADMIN_DOCUMENT_ADD, {
      doc_id: docId,
      resource_name: resourceName,
      page_url: pageUrl,
    });
    return response.data;
  },

  deleteDocument: async (docId) => {
    const response = await api.delete(ENDPOINTS.ADMIN_DOCUMENT_DELETE(docId));
    return response.data;
  },

  // Process Owners
  getProcessOwners: async (skip = 0, limit = 100) => {
    const response = await api.get(ENDPOINTS.ADMIN_PROCESS_OWNERS, {
      params: { skip, limit },
    });
    return response.data;
  },

  addProcessOwner: async (data) => {
    const response = await api.post(ENDPOINTS.ADMIN_PROCESS_OWNERS, data);
    return response.data;
  },

  updateProcessOwner: async (ownerId, data) => {
    const response = await api.put(ENDPOINTS.ADMIN_PROCESS_OWNER_BY_ID(ownerId), data);
    return response.data;
  },

  deleteProcessOwner: async (ownerId) => {
    const response = await api.delete(ENDPOINTS.ADMIN_PROCESS_OWNER_BY_ID(ownerId));
    return response.data;
  },

  // Safety Logs
  getSafetyLogs: async (skip = 0, limit = 100, categories = null, severity = null) => {
    const params = { skip, limit };
    if (categories) params.categories = categories;
    if (severity) params.severity = severity;
    
    const response = await api.get(ENDPOINTS.ADMIN_SAFETY_LOGS, { params });
    return response.data;
  },

  // Sessions
  getSessions: async () => {
    const response = await api.get(ENDPOINTS.ADMIN_SESSIONS);
    return response.data;
  },

  // Permissions
  getPermissions: async () => {
    const response = await api.get(ENDPOINTS.ADMIN_PERMISSIONS);
    return response.data;
  },
};