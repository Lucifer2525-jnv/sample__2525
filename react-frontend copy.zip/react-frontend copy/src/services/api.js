import axios from 'axios';
import { API_BASE_URL } from '../utils/constants';

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 120000, // 120 seconds
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('access_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response) {
      // Server responded with error status
      const { status, data } = error.response;
      
      if (status === 401) {
        // Unauthorized - clear token and redirect to login
        localStorage.removeItem('access_token');
        window.location.href = '/';
      } else if (status === 429) {
        console.error('Rate limit exceeded');
      } else if (status === 503) {
        console.error('Service unavailable');
      }
      
      return Promise.reject(data?.detail || error.message);
    } else if (error.request) {
      // Request made but no response
      return Promise.reject('Network error: Unable to connect to server');
    } else {
      // Something else happened
      return Promise.reject(error.message);
    }
  }
);

export default api;