import api from './api';
import { ENDPOINTS } from '../utils/constants';

export const authService = {
  // Validate token
  validateToken: async (token) => {
    try {
      const response = await api.get(ENDPOINTS.VALIDATE_TOKEN, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      return { success: true, data: response.data };
    } catch (error) {
      return { success: false, error };
    }
  },

  // Set token in localStorage
  setToken: (token) => {
    localStorage.setItem('access_token', token);
  },

  // Get token from localStorage
  getToken: () => {
    return localStorage.getItem('access_token');
  },

  // Remove token from localStorage
  removeToken: () => {
    localStorage.removeItem('access_token');
  },

  // Check if user is authenticated
  isAuthenticated: () => {
    return !!localStorage.getItem('access_token');
  },
};