import api from './api';
import { ENDPOINTS } from '../utils/constants';

export const chatService = {
  // Create new session
  createSession: async () => {
    const response = await api.post(ENDPOINTS.SESSIONS);
    return response.data;
  },

  // Send chat message
  sendMessage: async (message, sessionId) => {
    const response = await api.post(ENDPOINTS.CHAT, {
      message,
      session_id: sessionId,
    });
    return response.data;
  },

  // Get FAQs
  getFAQs: async () => {
    const response = await api.get(ENDPOINTS.FAQ);
    return response.data;
  },

  // Submit feedback
  submitFeedback: async (feedbackData) => {
    const response = await api.post(ENDPOINTS.FEEDBACK, feedbackData);
    return response.data;
  },

  // Get feedback stats
  getFeedbackStats: async () => {
    const response = await api.get(ENDPOINTS.FEEDBACK_STATS);
    return response.data;
  },

  // Get user's feedback history
  getMyFeedback: async () => {
    const response = await api.get(ENDPOINTS.MY_FEEDBACK);
    return response.data;
  },

  // Get system status
  getSystemStatus: async () => {
    const response = await api.get(ENDPOINTS.SYSTEM_STATUS);
    return response.data;
  },

  // Health check
  healthCheck: async () => {
    const response = await api.get(ENDPOINTS.HEALTH);
    return response.data;
  },
};