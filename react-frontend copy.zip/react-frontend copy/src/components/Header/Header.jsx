import { useState, useEffect } from 'react';
import styled from 'styled-components';
import { useAuth } from '../../context/AuthContext';
import { useChat } from '../../context/ChatContext';
import { chatService } from '../../services/chatService';
import { COLORS, GRADIENTS } from '../../utils/constants';

const HeaderContainer = styled.header`
  background: ${GRADIENTS.light};
  padding: 1rem 2rem;
  border-radius: 10px;
  margin-bottom: 1rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
`;

const HeaderContent = styled.div`
  display: grid;
  grid-template-columns: 2fr 2fr 3fr;
  gap: 1rem;
  align-items: center;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    gap: 0.5rem;
  }
`;

const LogoSection = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
`;

const Logo = styled.img`
  max-height: 60px;
`;

const LogoText = styled.h1`
  font-size: 1.5rem;
  background: ${GRADIENTS.primary};
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  margin: 0;
`;

const UserSection = styled.div`
  text-align: center;
`;

const UserEmail = styled.div`
  font-weight: 600;
  color: ${COLORS.text};
  font-size: 0.95rem;
`;

const ControlsSection = styled.div`
  display: flex;
  gap: 0.5rem;
  justify-content: flex-end;
  align-items: center;

  @media (max-width: 768px) {
    justify-content: center;
  }
`;

const Button = styled.button`
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 0.9rem;
  background: white;
  color: ${COLORS.text};
  border: 2px solid ${COLORS.border};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    border-color: ${COLORS.primary};
  }

  &:active {
    transform: translateY(0);
  }
`;

const StatusIndicator = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.9rem;
  color: ${COLORS.text};
`;

const StatusDot = styled.span`
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: ${props => props.online ? COLORS.success : COLORS.error};
  box-shadow: 0 0 10px ${props => props.online ? 'rgba(46, 204, 113, 0.5)' : 'rgba(231, 76, 60, 0.5)'};
  animation: pulse 2s infinite;

  @keyframes pulse {
    0%, 100% {
      transform: scale(1);
    }
    50% {
      transform: scale(1.05);
    }
  }
`;

const Header = () => {
  const { user, logout } = useAuth();
  const { createNewSession, clearSession } = useChat();
  const [isOnline, setIsOnline] = useState(false);

  useEffect(() => {
    checkHealth();
    const interval = setInterval(checkHealth, 30000); // Check every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const checkHealth = async () => {
    try {
      await chatService.healthCheck();
      setIsOnline(true);
    } catch {
      setIsOnline(false);
    }
  };

  const handleNewSession = async () => {
    await createNewSession();
  };

  const handleClearSession = () => {
    clearSession();
  };

  return (
    <HeaderContainer>
      <HeaderContent>
        <LogoSection>
          <LogoText>GSK EAI Chatbot</LogoText>
        </LogoSection>

        <UserSection>
          <UserEmail>📧 {user || 'User'}</UserEmail>
        </UserSection>

        <ControlsSection>
          <Button onClick={handleNewSession}>
            ➕ New Session
          </Button>
          <Button onClick={handleClearSession}>
            🔄 Clear Session
          </Button>
          <StatusIndicator>
            <StatusDot online={isOnline} />
            {isOnline ? 'Online' : 'Offline'}
          </StatusIndicator>
        </ControlsSection>
      </HeaderContent>
    </HeaderContainer>
  );
};

export default Header;