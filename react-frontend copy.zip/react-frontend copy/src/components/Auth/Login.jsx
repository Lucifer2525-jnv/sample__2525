import { useState } from 'react';
import styled from 'styled-components';
import { useAuth } from '../../context/AuthContext';
import { COLORS, GRADIENTS } from '../../utils/constants';

const LoginContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background: ${GRADIENTS.light};
`;

const LoginCard = styled.div`
  background: white;
  border-radius: 20px;
  padding: 3rem;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
  max-width: 500px;
  width: 90%;
  text-align: center;
`;

const Title = styled.h1`
  background: ${GRADIENTS.primary};
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  font-size: 2.5rem;
  margin-bottom: 1rem;
`;

const Subtitle = styled.p`
  color: ${COLORS.textLight};
  margin-bottom: 2rem;
  font-size: 1.1rem;
`;

const InputGroup = styled.div`
  margin-bottom: 1.5rem;
  text-align: left;
`;

const Label = styled.label`
  display: block;
  color: ${COLORS.text};
  font-weight: 600;
  margin-bottom: 0.5rem;
`;

const Input = styled.input`
  width: 100%;
  padding: 1rem;
  border: 2px solid ${COLORS.border};
  border-radius: 10px;
  font-size: 1rem;
  transition: all 0.3s ease;
  box-sizing: border-box;

  &:focus {
    outline: none;
    border-color: ${COLORS.primary};
    box-shadow: 0 0 0 3px rgba(255, 165, 0, 0.1);
  }
`;

const Button = styled.button`
  width: 100%;
  padding: 1rem;
  background: ${GRADIENTS.primary};
  color: white;
  border: none;
  border-radius: 10px;
  font-size: 1.1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(255, 69, 0, 0.3);
  }

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
  }
`;

const ErrorMessage = styled.div`
  background: #fee;
  color: ${COLORS.error};
  padding: 1rem;
  border-radius: 10px;
  margin-bottom: 1rem;
  border-left: 4px solid ${COLORS.error};
`;

const InfoBox = styled.div`
  background: ${GRADIENTS.success};
  padding: 1rem;
  border-radius: 10px;
  margin-top: 1.5rem;
  font-size: 0.9rem;
  color: ${COLORS.text};
`;

const Login = () => {
  const [token, setToken] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!token.trim()) {
      setError('Please enter your access token');
      return;
    }

    setLoading(true);
    try {
      await login(token);
    } catch (err) {
      setError('Invalid token. Please check and try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <LoginContainer>
      <LoginCard>
        <Title>GSK EAI Chatbot</Title>
        <Subtitle>Enter your SSO access token to continue</Subtitle>

        {error && <ErrorMessage>{error}</ErrorMessage>}

        <form onSubmit={handleSubmit}>
          <InputGroup>
            <Label htmlFor="token">Access Token</Label>
            <Input
              id="token"
              type="text"
              placeholder="Paste your access token here"
              value={token}
              onChange={(e) => setToken(e.target.value)}
              disabled={loading}
            />
          </InputGroup>

          <Button type="submit" disabled={loading}>
            {loading ? 'Validating...' : 'Login'}
          </Button>
        </form>

        <InfoBox>
          <strong>Note:</strong> For now, manually paste your SSO access token.
          Contact your administrator if you need assistance.
        </InfoBox>
      </LoginCard>
    </LoginContainer>
  );
};

export default Login;