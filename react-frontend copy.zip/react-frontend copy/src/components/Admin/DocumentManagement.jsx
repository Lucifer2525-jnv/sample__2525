import { useState, useEffect } from 'react';
import styled from 'styled-components';
import { adminService } from '../../services/adminService';
import { COLORS, GRADIENTS } from '../../utils/constants';

const Container = styled.div`
  padding: 2rem;
`;

const Header = styled.div`
  background: ${GRADIENTS.primary};
  color: white;
  padding: 1.5rem;
  border-radius: 15px;
  margin-bottom: 2rem;

  h2 {
    margin: 0 0 0.5rem 0;
    font-size: 1.8rem;
  }

  p {
    margin: 0;
    opacity: 0.9;
  }
`;

const FiltersSection = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
  margin-bottom: 2rem;
`;

const FilterGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`;

const Label = styled.label`
  font-weight: 600;
  color: ${COLORS.text};
`;

const Select = styled.select`
  padding: 0.75rem;
  border: 2px solid ${COLORS.border};
  border-radius: 8px;
  font-size: 1rem;

  &:focus {
    outline: none;
    border-color: ${COLORS.primary};
  }
`;

const Input = styled.input`
  padding: 0.75rem;
  border: 2px solid ${COLORS.border};
  border-radius: 8px;
  font-size: 1rem;

  &:focus {
    outline: none;
    border-color: ${COLORS.primary};
  }
`;

const Button = styled.button`
  padding: 0.75rem 1.5rem;
  background: ${props => props.variant === 'primary' ? GRADIENTS.primary : 'white'};
  color: ${props => props.variant === 'primary' ? 'white' : COLORS.text};
  border: 2px solid ${props => props.variant === 'primary' ? 'transparent' : COLORS.border};
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  }

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
  }
`;

const StatsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
  margin-bottom: 2rem;
`;

const StatCard = styled.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.1);
  text-align: center;

  h3 {
    font-size: 2rem;
    color: ${props => props.color || COLORS.secondary};
    margin: 0 0 0.5rem 0;
  }

  p {
    margin: 0;
    color: ${COLORS.textLight};
  }
`;

const Table = styled.div`
  background: white;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.1);
`;

const TableHeader = styled.div`
  display: grid;
  grid-template-columns: 1fr 2fr 1fr 1fr 1fr 150px;
  gap: 1rem;
  padding: 1rem;
  background: ${GRADIENTS.light};
  font-weight: 600;
  color: ${COLORS.text};
  border-bottom: 2px solid ${COLORS.border};
`;

const TableRow = styled.div`
  display: grid;
  grid-template-columns: 1fr 2fr 1fr 1fr 1fr 150px;
  gap: 1rem;
  padding: 1rem;
  border-bottom: 1px solid ${COLORS.border};
  transition: all 0.2s ease;

  &:hover {
    background: ${COLORS.backgroundLight};
  }

  &:last-child {
    border-bottom: none;
  }
`;

const Cell = styled.div`
  display: flex;
  align-items: center;
  font-size: 0.9rem;
  color: ${COLORS.text};
  overflow: hidden;
  text-overflow: ellipsis;
`;

const StatusBadge = styled.span`
  padding: 0.25rem 0.75rem;
  border-radius: 20px;
  font-size: 0.8rem;
  font-weight: 600;
  background: ${props => {
    if (props.status === 'processed' || props.status === 'indexed') return COLORS.success;
    if (props.status === 'processing') return COLORS.warning;
    if (props.status === 'failed') return COLORS.error;
    return COLORS.textLight;
  }};
  color: white;
`;

const ActiveBadge = styled.span`
  padding: 0.25rem 0.75rem;
  border-radius: 20px;
  font-size: 0.8rem;
  font-weight: 600;
  background: ${props => props.active ? COLORS.success : COLORS.error};
  color: white;
`;

const ActionButtons = styled.div`
  display: flex;
  gap: 0.5rem;
`;

const IconButton = styled.button`
  padding: 0.5rem;
  background: ${props => props.danger ? COLORS.error : COLORS.primary};
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.2s ease;
  font-size: 0.9rem;

  &:hover {
    transform: scale(1.1);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
  }
`;

const Pagination = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 1rem;
  margin-top: 2rem;
  padding: 1rem;
`;

const LoadingText = styled.div`
  text-align: center;
  padding: 3rem;
  color: ${COLORS.textLight};
  font-size: 1.1rem;
`;

const DocumentManagement = () => {
  const [documents, setDocuments] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('');
  const [sourceFilter, setSourceFilter] = useState('');
  const [activeFilter, setActiveFilter] = useState('All');
  const [page, setPage] = useState(1);
  const itemsPerPage = 25;

  useEffect(() => {
    loadDocuments();
  }, [statusFilter, sourceFilter]);

  const loadDocuments = async () => {
    setLoading(true);
    try {
      const data = await adminService.getDocuments(
        statusFilter || null,
        sourceFilter || null
      );
      setDocuments(data.documents || []);
      setStats(data.stats || {});
    } catch (error) {
      console.error('Failed to load documents:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleToggleActive = async (docId) => {
    try {
      await adminService.toggleDocumentActive(docId);
      loadDocuments();
    } catch (error) {
      alert('Failed to toggle document status');
    }
  };

  const handleDelete = async (docId) => {
    if (!confirm('Are you sure you want to delete this document?')) return;
    
    try {
      await adminService.deleteDocument(docId);
      loadDocuments();
    } catch (error) {
      alert('Failed to delete document');
    }
  };

  // Filter documents by active status
  const filteredDocs = documents.filter(doc => {
    if (activeFilter === 'Active') return doc.is_active;
    if (activeFilter === 'Inactive') return !doc.is_active;
    return true;
  });

  // Pagination
  const totalPages = Math.ceil(filteredDocs.length / itemsPerPage);
  const paginatedDocs = filteredDocs.slice(
    (page - 1) * itemsPerPage,
    page * itemsPerPage
  );

  if (loading) {
    return <LoadingText>Loading documents...</LoadingText>;
  }

  return (
    <Container>
      <Header>
        <h2>📄 Document Management</h2>
        <p>Manage and monitor document indexing status</p>
      </Header>

      <FiltersSection>
        <FilterGroup>
          <Label>Status Filter</Label>
          <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
            <option value="">All</option>
            <option value="indexed">Indexed</option>
            <option value="None">Non-Indexed</option>
          </Select>
        </FilterGroup>

        <FilterGroup>
          <Label>Source Filter</Label>
          <Input
            type="text"
            placeholder="Filter by source"
            value={sourceFilter}
            onChange={(e) => setSourceFilter(e.target.value)}
          />
        </FilterGroup>

        <FilterGroup>
          <Label>Active Status</Label>
          <Select value={activeFilter} onChange={(e) => setActiveFilter(e.target.value)}>
            <option value="All">All</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </Select>
        </FilterGroup>

        <FilterGroup>
          <Label>&nbsp;</Label>
          <Button variant="primary" onClick={loadDocuments}>
            🔄 Refresh
          </Button>
        </FilterGroup>
      </FiltersSection>

      <StatsGrid>
        <StatCard color={COLORS.secondary}>
          <h3>{filteredDocs.length}</h3>
          <p>Filtered Documents</p>
        </StatCard>
        <StatCard color={COLORS.success}>
          <h3>{filteredDocs.filter(d => d.is_active).length}</h3>
          <p>Active Documents</p>
        </StatCard>
        <StatCard color={COLORS.warning}>
          <h3>{filteredDocs.filter(d => d.indexing_status === 'indexed' || d.indexing_status === 'processed').length}</h3>
          <p>Indexed</p>
        </StatCard>
      </StatsGrid>

      <Table>
        <TableHeader>
          <div>ID</div>
          <div>Title</div>
          <div>Source</div>
          <div>Status</div>
          <div>Active</div>
          <div>Actions</div>
        </TableHeader>
        {paginatedDocs.map((doc) => (
          <TableRow key={doc.id}>
            <Cell title={doc.id}>{doc.id.substring(0, 8)}...</Cell>
            <Cell title={doc.title}>{doc.title}</Cell>
            <Cell>{doc.source}</Cell>
            <Cell>
              <StatusBadge status={doc.indexing_status}>
                {doc.indexing_status || 'N/A'}
              </StatusBadge>
            </Cell>
            <Cell>
              <ActiveBadge active={doc.is_active}>
                {doc.is_active ? '🟢 Active' : '🔴 Inactive'}
              </ActiveBadge>
            </Cell>
            <Cell>
              <ActionButtons>
                <IconButton onClick={() => handleToggleActive(doc.id)}>
                  🔄
                </IconButton>
                <IconButton danger onClick={() => handleDelete(doc.id)}>
                  🗑️
                </IconButton>
              </ActionButtons>
            </Cell>
          </TableRow>
        ))}
      </Table>

      {totalPages > 1 && (
        <Pagination>
          <Button onClick={() => setPage(1)} disabled={page === 1}>
            ⏮️ First
          </Button>
          <Button onClick={() => setPage(page - 1)} disabled={page === 1}>
            ◀️ Previous
          </Button>
          <span>Page {page} of {totalPages}</span>
          <Button onClick={() => setPage(page + 1)} disabled={page === totalPages}>
            Next ▶️
          </Button>
          <Button onClick={() => setPage(totalPages)} disabled={page === totalPages}>
            Last ⏭️
          </Button>
        </Pagination>
      )}
    </Container>
  );
};

export default DocumentManagement;