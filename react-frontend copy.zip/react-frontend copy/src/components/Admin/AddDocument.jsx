import { useState } from 'react';
import styled from 'styled-components';
import { adminService } from '../../services/adminService';
import { COLORS, GRADIENTS } from '../../utils/constants';

const Container = styled.div`
  padding: 2rem;
`;

const Header = styled.div`
  background: ${GRADIENTS.primary};
  color: white;
  padding: 1.5rem;
  border-radius: 15px;
  margin-bottom: 2rem;

  h2 {
    margin: 0 0 0.5rem 0;
    font-size: 1.8rem;
  }

  p {
    margin: 0;
    opacity: 0.9;
  }
`;

const Form = styled.form`
  background: white;
  border-radius: 12px;
  padding: 2rem;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.1);
  max-width: 800px;
  margin: 0 auto;
`;

const FormGroup = styled.div`
  margin-bottom: 1.5rem;
`;

const Label = styled.label`
  display: block;
  font-weight: 600;
  color: ${COLORS.text};
  margin-bottom: 0.5rem;
`;

const Select = styled.select`
  width: 100%;
  padding: 1rem;
  border: 2px solid ${COLORS.border};
  border-radius: 10px;
  font-size: 1rem;
  transition: all 0.3s ease;

  &:focus {
    outline: none;
    border-color: ${COLORS.primary};
    box-shadow: 0 0 0 3px rgba(255, 165, 0, 0.1);
  }
`;

const Input = styled.input`
  width: 100%;
  padding: 1rem;
  border: 2px solid ${COLORS.border};
  border-radius: 10px;
  font-size: 1rem;
  transition: all 0.3s ease;
  box-sizing: border-box;

  &:focus {
    outline: none;
    border-color: ${COLORS.primary};
    box-shadow: 0 0 0 3px rgba(255, 165, 0, 0.1);
  }
`;

const InputWrapper = styled.div`
  display: flex;
  gap: 0.5rem;
  align-items: flex-end;
`;

const InfoButton = styled.button`
  padding: 1rem;
  background: ${COLORS.info};
  color: white;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  font-weight: 600;
  transition: all 0.3s ease;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(52, 152, 219, 0.3);
  }
`;

const InfoBox = styled.div`
  background: ${GRADIENTS.success};
  padding: 1.5rem;
  border-radius: 10px;
  margin-top: 1rem;
  font-size: 0.9rem;
  color: ${COLORS.text};

  h4 {
    margin: 0 0 1rem 0;
    color: ${COLORS.text};
  }

  code {
    display: block;
    background: white;
    padding: 0.5rem;
    border-radius: 6px;
    margin: 0.5rem 0;
    font-family: 'Courier New', monospace;
    color: ${COLORS.primary};
  }

  strong {
    color: ${COLORS.text};
  }
`;

const Button = styled.button`
  width: 100%;
  padding: 1rem;
  background: ${GRADIENTS.primary};
  color: white;
  border: none;
  border-radius: 10px;
  font-size: 1.1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(255, 69, 0, 0.3);
  }

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
  }
`;

const SuccessMessage = styled.div`
  background: ${COLORS.success};
  color: white;
  padding: 1rem;
  border-radius: 10px;
  margin-bottom: 1rem;
  text-align: center;
  font-weight: 600;
`;

const ErrorMessage = styled.div`
  background: ${COLORS.error};
  color: white;
  padding: 1rem;
  border-radius: 10px;
  margin-bottom: 1rem;
  text-align: center;
  font-weight: 600;
`;

const AddDocument = () => {
  const [resourceName, setResourceName] = useState('Confluence');
  const [pageUrl, setPageUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');
  const [showInfo, setShowInfo] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSuccess('');
    setError('');

    if (!pageUrl.trim()) {
      setError('Please enter a document link or ID');
      return;
    }

    setLoading(true);
    try {
      const response = await adminService.addDocument(
        pageUrl.trim(),
        resourceName,
        pageUrl.trim()
      );
      setSuccess('Document added successfully!');
      setPageUrl('');
      setTimeout(() => setSuccess(''), 5000);
    } catch (err) {
      setError(err || 'Failed to add document');
      setTimeout(() => setError(''), 5000);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container>
      <Header>
        <h2>➕ Add Document</h2>
        <p>Submit new documents for indexing</p>
      </Header>

      <Form onSubmit={handleSubmit}>
        {success && <SuccessMessage>✅ {success}</SuccessMessage>}
        {error && <ErrorMessage>❌ {error}</ErrorMessage>}

        <FormGroup>
          <Label htmlFor="resourceName">Resource Name</Label>
          <Select
            id="resourceName"
            value={resourceName}
            onChange={(e) => setResourceName(e.target.value)}
          >
            <option value="Confluence">Confluence</option>
            <option value="VQD">VQD</option>
          </Select>
        </FormGroup>

        <FormGroup>
          <Label htmlFor="pageUrl">Document Link or ID</Label>
          <InputWrapper>
            <Input
              id="pageUrl"
              type="text"
              placeholder="Enter the Document Link or Document ID"
              value={pageUrl}
              onChange={(e) => setPageUrl(e.target.value)}
              disabled={loading}
            />
            <InfoButton type="button" onClick={() => setShowInfo(!showInfo)}>
              ℹ️
            </InfoButton>
          </InputWrapper>
        </FormGroup>

        {showInfo && (
          <InfoBox>
            <h4>📋 Document URL/ID Format Guide</h4>
            
            <strong>For Confluence:</strong>
            <code>Link: https://my-gsk.atlassian.net/wiki/spaces/GDPPE/pages/123456/page_info</code>
            <strong>OR</strong>
            <code>Page_ID: 123456</code>
            
            <strong>For VQD:</strong>
            <code>Link: https://gsk-qualitysuite.veevavault.com/ui/#doc_info/1234567/1/0</code>
            <strong>OR</strong>
            <code>DOC_ID: VQD-TRN-12345</code>
            
            <p style={{ marginTop: '1rem', marginBottom: 0 }}>
              💡 <strong>Tip:</strong> You can paste either the complete URL or just the ID!
            </p>
          </InfoBox>
        )}

        <Button type="submit" disabled={loading}>
          {loading ? 'Submitting...' : 'Submit Document'}
        </Button>
      </Form>
    </Container>
  );
};

export default AddDocument;