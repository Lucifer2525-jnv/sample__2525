import { useState, useEffect } from 'react';
import styled from 'styled-components';
import { adminService } from '../../services/adminService';
import { COLORS, GRADIENTS } from '../../utils/constants';

const Container = styled.div`
  padding: 2rem;
`;

const Header = styled.div`
  background: ${GRADIENTS.primary};
  color: white;
  padding: 1.5rem;
  border-radius: 15px;
  margin-bottom: 2rem;

  h2 {
    margin: 0 0 0.5rem 0;
    font-size: 1.8rem;
  }

  p {
    margin: 0;
    opacity: 0.9;
  }
`;

const Section = styled.div`
  background: white;
  border-radius: 12px;
  padding: 2rem;
  margin-bottom: 2rem;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.1);
`;

const SectionTitle = styled.h3`
  color: ${COLORS.text};
  margin: 0 0 1.5rem 0;
`;

const Table = styled.div`
  overflow-x: auto;
`;

const TableHeader = styled.div`
  display: grid;
  grid-template-columns: 50px 1fr 1fr 1fr 1fr 1fr 100px;
  gap: 1rem;
  padding: 1rem;
  background: ${GRADIENTS.light};
  font-weight: 600;
  border-radius: 8px;
  margin-bottom: 0.5rem;
`;

const TableRow = styled.div`
  display: grid;
  grid-template-columns: 50px 1fr 1fr 1fr 1fr 1fr 100px;
  gap: 1rem;
  padding: 1rem;
  border-bottom: 1px solid ${COLORS.border};
  transition: all 0.2s ease;

  &:hover {
    background: ${COLORS.backgroundLight};
  }
`;

const Cell = styled.div`
  display: flex;
  align-items: center;
  font-size: 0.9rem;
  color: ${COLORS.text};
`;

const Form = styled.form`
  display: grid;
  gap: 1rem;
`;

const FormRow = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
`;

const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`;

const Label = styled.label`
  font-weight: 600;
  color: ${COLORS.text};
  font-size: 0.9rem;
`;

const Input = styled.input`
  padding: 0.75rem;
  border: 2px solid ${COLORS.border};
  border-radius: 8px;
  font-size: 1rem;

  &:focus {
    outline: none;
    border-color: ${COLORS.primary};
  }
`;

const TextArea = styled.textarea`
  padding: 0.75rem;
  border: 2px solid ${COLORS.border};
  border-radius: 8px;
  font-size: 1rem;
  min-height: 80px;
  resize: vertical;

  &:focus {
    outline: none;
    border-color: ${COLORS.primary};
  }
`;

const Button = styled.button`
  padding: 0.75rem 1.5rem;
  background: ${props => props.variant === 'danger' ? COLORS.error : GRADIENTS.primary};
  color: white;
  border: none;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
  }

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
  }
`;

const IconButton = styled.button`
  padding: 0.5rem;
  background: ${COLORS.error};
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.2s ease;

  &:hover {
    transform: scale(1.1);
  }
`;

const LoadingText = styled.div`
  text-align: center;
  padding: 2rem;
  color: ${COLORS.textLight};
`;

const Message = styled.div`
  padding: 1rem;
  border-radius: 8px;
  margin-bottom: 1rem;
  background: ${props => props.type === 'success' ? COLORS.success : COLORS.error};
  color: white;
  text-align: center;
  font-weight: 600;
`;

const DeleteSection = styled.div`
  display: flex;
  gap: 1rem;
  align-items: flex-end;
`;

const ProcessOwners = () => {
  const [owners, setOwners] = useState([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState({ text: '', type: '' });
  
  // Form state
  const [formData, setFormData] = useState({
    Domain: '',
    PrimaryProcessOwner: '',
    SecondaryProcessOwner: '',
    Remark: '',
    Comments: ''
  });

  const [deleteId, setDeleteId] = useState('');

  useEffect(() => {
    loadOwners();
  }, []);

  const loadOwners = async () => {
    setLoading(true);
    try {
      const data = await adminService.getProcessOwners();
      setOwners(data);
    } catch (error) {
      showMessage('Failed to load process owners', 'error');
    } finally {
      setLoading(false);
    }
  };

  const showMessage = (text, type) => {
    setMessage({ text, type });
    setTimeout(() => setMessage({ text: '', type: '' }), 5000);
  };

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.Domain || !formData.PrimaryProcessOwner) {
      showMessage('Domain and Primary Process Owner are required', 'error');
      return;
    }

    try {
      await adminService.addProcessOwner(formData);
      showMessage('Process owner added successfully', 'success');
      setFormData({
        Domain: '',
        PrimaryProcessOwner: '',
        SecondaryProcessOwner: '',
        Remark: '',
        Comments: ''
      });
      loadOwners();
    } catch (error) {
      showMessage('Failed to add process owner', 'error');
    }
  };

  const handleDelete = async () => {
    if (!deleteId) {
      showMessage('Please enter a valid ID', 'error');
      return;
    }

    if (!confirm(`Are you sure you want to delete process owner with ID ${deleteId}?`)) {
      return;
    }

    try {
      await adminService.deleteProcessOwner(deleteId);
      showMessage('Process owner deleted successfully', 'success');
      setDeleteId('');
      loadOwners();
    } catch (error) {
      showMessage('Failed to delete process owner', 'error');
    }
  };

  if (loading) {
    return <LoadingText>Loading process owners...</LoadingText>;
  }

  return (
    <Container>
      <Header>
        <h2>📋 Manage Process Owners</h2>
        <p>Add, view, and manage Process Owners</p>
      </Header>

      {message.text && <Message type={message.type}>{message.text}</Message>}

      <Section>
        <SectionTitle>Process Owners List</SectionTitle>
        <Table>
          <TableHeader>
            <div>ID</div>
            <div>Domain</div>
            <div>Primary Owner</div>
            <div>Secondary Owner</div>
            <div>Remark</div>
            <div>Comments</div>
            <div>Actions</div>
          </TableHeader>
          {owners.map((owner) => (
            <TableRow key={owner.id}>
              <Cell>{owner.id}</Cell>
              <Cell>{owner.Domain}</Cell>
              <Cell>{owner.PrimaryProcessOwner}</Cell>
              <Cell>{owner.SecondaryProcessOwner || 'N/A'}</Cell>
              <Cell>{owner.Remark || 'N/A'}</Cell>
              <Cell>{owner.Comments || 'N/A'}</Cell>
              <Cell>
                <IconButton onClick={() => setDeleteId(owner.id.toString())}>
                  🗑️
                </IconButton>
              </Cell>
            </TableRow>
          ))}
        </Table>
      </Section>

      <Section>
        <SectionTitle>Add New Process Owner</SectionTitle>
        <Form onSubmit={handleSubmit}>
          <FormRow>
            <FormGroup>
              <Label>Domain *</Label>
              <Input
                name="Domain"
                value={formData.Domain}
                onChange={handleInputChange}
                placeholder="Enter domain"
                required
              />
            </FormGroup>
            <FormGroup>
              <Label>Primary Process Owner *</Label>
              <Input
                name="PrimaryProcessOwner"
                value={formData.PrimaryProcessOwner}
                onChange={handleInputChange}
                placeholder="Enter primary owner"
                required
              />
            </FormGroup>
            <FormGroup>
              <Label>Secondary Process Owner</Label>
              <Input
                name="SecondaryProcessOwner"
                value={formData.SecondaryProcessOwner}
                onChange={handleInputChange}
                placeholder="Enter secondary owner"
              />
            </FormGroup>
          </FormRow>
          
          <FormRow>
            <FormGroup>
              <Label>Remark</Label>
              <Input
                name="Remark"
                value={formData.Remark}
                onChange={handleInputChange}
                placeholder="Enter remark"
              />
            </FormGroup>
            <FormGroup>
              <Label>Comments</Label>
              <TextArea
                name="Comments"
                value={formData.Comments}
                onChange={handleInputChange}
                placeholder="Enter comments"
              />
            </FormGroup>
          </FormRow>

          <Button type="submit">Add Process Owner</Button>
        </Form>
      </Section>

      <Section>
        <SectionTitle>Delete Process Owner</SectionTitle>
        <DeleteSection>
          <FormGroup style={{ flex: 1 }}>
            <Label>Enter ID of the row to delete</Label>
            <Input
              type="number"
              value={deleteId}
              onChange={(e) => setDeleteId(e.target.value)}
              placeholder="Enter row ID"
            />
          </FormGroup>
          <Button variant="danger" onClick={handleDelete}>
            Delete Row
          </Button>
        </DeleteSection>
      </Section>
    </Container>
  );
};

export default ProcessOwners;