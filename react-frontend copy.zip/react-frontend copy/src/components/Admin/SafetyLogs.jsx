import { useState, useEffect } from 'react';
import styled from 'styled-components';
import { adminService } from '../../services/adminService';
import { COLORS, GRADIENTS } from '../../utils/constants';

const Container = styled.div`
  padding: 2rem;
`;

const Header = styled.div`
  background: ${GRADIENTS.primary};
  color: white;
  padding: 1.5rem;
  border-radius: 15px;
  margin-bottom: 2rem;

  h2 {
    margin: 0 0 0.5rem 0;
    font-size: 1.8rem;
  }

  p {
    margin: 0;
    opacity: 0.9;
  }
`;

const FiltersSection = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
  margin-bottom: 2rem;
`;

const FilterGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`;

const Label = styled.label`
  font-weight: 600;
  color: ${COLORS.text};
`;

const Select = styled.select`
  padding: 0.75rem;
  border: 2px solid ${COLORS.border};
  border-radius: 8px;
  font-size: 1rem;

  &:focus {
    outline: none;
    border-color: ${COLORS.primary};
  }
`;

const Button = styled.button`
  padding: 0.75rem 1.5rem;
  background: ${GRADIENTS.primary};
  color: white;
  border: none;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  }
`;

const LogsContainer = styled.div`
  display: grid;
  gap: 1rem;
`;

const LogCard = styled.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.1);
  border-left: 5px solid ${props => {
    if (props.severity === 'High') return COLORS.error;
    if (props.severity === 'Medium') return COLORS.warning;
    return COLORS.info;
  }};
  transition: all 0.3s ease;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
  }
`;

const LogHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid ${COLORS.border};
`;

const LogId = styled.div`
  font-weight: 600;
  color: ${COLORS.text};
  font-size: 1.1rem;
`;

const SeverityBadge = styled.span`
  padding: 0.25rem 0.75rem;
  border-radius: 20px;
  font-size: 0.85rem;
  font-weight: 600;
  background: ${props => {
    if (props.severity === 'High') return COLORS.error;
    if (props.severity === 'Medium') return COLORS.warning;
    return COLORS.info;
  }};
  color: white;
`;

const LogDetail = styled.div`
  margin-bottom: 0.75rem;
  
  strong {
    color: ${COLORS.text};
    display: inline-block;
    min-width: 120px;
  }
  
  span {
    color: ${COLORS.textLight};
  }
`;

const LoadingText = styled.div`
  text-align: center;
  padding: 3rem;
  color: ${COLORS.textLight};
  font-size: 1.1rem;
`;

const EmptyState = styled.div`
  text-align: center;
  padding: 3rem;
  background: white;
  border-radius: 12px;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.1);
  
  h3 {
    color: ${COLORS.text};
    margin-bottom: 0.5rem;
  }
  
  p {
    color: ${COLORS.textLight};
  }
`;

const SafetyLogs = () => {
  const [logs, setLogs] = useState([]);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [categoriesFilter, setCategoriesFilter] = useState('');
  const [severityFilter, setSeverityFilter] = useState('');

  useEffect(() => {
    loadLogs();
  }, []);

  const loadLogs = async () => {
    setLoading(true);
    try {
      const data = await adminService.getSafetyLogs(
        0,
        100,
        categoriesFilter || null,
        severityFilter || null
      );
      setLogs(data.safety_logs || []);
      setTotalCount(data.total_count || 0);
    } catch (error) {
      console.error('Failed to load safety logs:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = () => {
    loadLogs();
  };

  if (loading) {
    return <LoadingText>Loading safety logs...</LoadingText>;
  }

  return (
    <Container>
      <Header>
        <h2>🛡️ Content Safety Monitoring</h2>
        <p>Monitor and analyze content safety events and PII detection</p>
      </Header>

      <FiltersSection>
        <FilterGroup>
          <Label>Categories</Label>
          <Select value={categoriesFilter} onChange={(e) => setCategoriesFilter(e.target.value)}>
            <option value="">All</option>
            <option value="Sensitive">Sensitive</option>
            <option value="PII">PII</option>
            <option value="Other">Other</option>
          </Select>
        </FilterGroup>

        <FilterGroup>
          <Label>Severity</Label>
          <Select value={severityFilter} onChange={(e) => setSeverityFilter(e.target.value)}>
            <option value="">All</option>
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
          </Select>
        </FilterGroup>

        <FilterGroup>
          <Label>&nbsp;</Label>
          <Button onClick={handleRefresh}>
            🔄 Refresh
          </Button>
        </FilterGroup>
      </FiltersSection>

      {logs.length === 0 ? (
        <EmptyState>
          <h3>📋 No Safety Logs Found</h3>
          <p>No safety logs match the current filters or no logs are available.</p>
        </EmptyState>
      ) : (
        <>
          <div style={{ marginBottom: '1rem', color: COLORS.text, fontWeight: 600 }}>
            🛡️ Safety Logs ({totalCount} total)
          </div>
          <LogsContainer>
            {logs.map((log) => (
              <LogCard key={log.id} severity={log.severity}>
                <LogHeader>
                  <LogId>Log ID: {log.id}</LogId>
                  <SeverityBadge severity={log.severity}>
                    {log.severity || 'N/A'}
                  </SeverityBadge>
                </LogHeader>
                
                <LogDetail>
                  <strong>Chat ID:</strong>
                  <span> {log.chat_id}</span>
                </LogDetail>
                
                <LogDetail>
                  <strong>Categories:</strong>
                  <span> {log.categories || 'N/A'}</span>
                </LogDetail>
                
                <LogDetail>
                  <strong>PII Details:</strong>
                  <span> {log.pii_details || 'None'}</span>
                </LogDetail>
                
                <LogDetail>
                  <strong>Created Date:</strong>
                  <span> {new Date(log.created_date).toLocaleString()}</span>
                </LogDetail>
              </LogCard>
            ))}
          </LogsContainer>
        </>
      )}
    </Container>
  );
};

export default SafetyLogs;