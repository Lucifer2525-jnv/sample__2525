import { useState } from 'react';
import styled from 'styled-components';
import DocumentManagement from './DocumentManagement';
import SafetyLogs from './SafetyLogs';
import AddDocument from './AddDocument';
import ProcessOwners from './ProcessOwners';
import { COLORS, GRADIENTS } from '../../utils/constants';

const Container = styled.div`
  min-height: 100vh;
  background: ${GRADIENTS.light};
  padding: 2rem;
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
`;

const Title = styled.h1`
  background: ${GRADIENTS.primary};
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  font-size: 2.5rem;
  margin: 0;
`;

const BackButton = styled.button`
  padding: 0.75rem 1.5rem;
  background: white;
  color: ${COLORS.text};
  border: 2px solid ${COLORS.border};
  border-radius: 10px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    border-color: ${COLORS.primary};
  }
`;

const TabsContainer = styled.div`
  display: flex;
  gap: 1rem;
  margin-bottom: 2rem;
  overflow-x: auto;
  padding-bottom: 0.5rem;

  &::-webkit-scrollbar {
    height: 6px;
  }

  &::-webkit-scrollbar-track {
    background: ${COLORS.backgroundLight};
    border-radius: 10px;
  }

  &::-webkit-scrollbar-thumb {
    background: ${GRADIENTS.secondary};
    border-radius: 10px;
  }
`;

const Tab = styled.button`
  padding: 1rem 2rem;
  background: ${props => props.active ? GRADIENTS.primary : 'white'};
  color: ${props => props.active ? 'white' : COLORS.text};
  border: 2px solid ${props => props.active ? 'transparent' : COLORS.border};
  border-radius: 10px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  white-space: nowrap;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    ${props => !props.active && `border-color: ${COLORS.primary};`}
  }
`;

const ContentContainer = styled.div`
  background: white;
  border-radius: 15px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
  overflow: hidden;
`;

const AdminPanel = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState('documents');

  const tabs = [
    { id: 'documents', label: '📄 Documents', component: DocumentManagement },
    { id: 'safety', label: '🛡️ Safety Logs', component: SafetyLogs },
    { id: 'add-document', label: '➕ Add Document', component: AddDocument },
    { id: 'process-owners', label: '📋 Process Owners', component: ProcessOwners },
  ];

  const ActiveComponent = tabs.find(tab => tab.id === activeTab)?.component;

  return (
    <Container>
      <Header>
        <Title>Admin Panel</Title>
        <BackButton onClick={onBack}>
          💬 Back to Chat
        </BackButton>
      </Header>

      <TabsContainer>
        {tabs.map(tab => (
          <Tab
            key={tab.id}
            active={activeTab === tab.id}
            onClick={() => setActiveTab(tab.id)}
          >
            {tab.label}
          </Tab>
        ))}
      </TabsContainer>

      <ContentContainer>
        {ActiveComponent && <ActiveComponent />}
      </ContentContainer>
    </Container>
  );
};

export default AdminPanel;