import styled from 'styled-components';
import { useAuth } from '../../context/AuthContext';
import { useChat } from '../../context/ChatContext';
import FAQList from './FAQList';
import FeedbackStats from './FeedbackStats';
import { COLORS, GRADIENTS } from '../../utils/constants';

const SidebarContainer = styled.aside`
  width: 300px;
  background: ${GRADIENTS.light};
  padding: 1.5rem;
  border-radius: 15px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
  overflow-y: auto;
  height: calc(100vh - 200px);

  &::-webkit-scrollbar {
    width: 8px;
  }

  &::-webkit-scrollbar-track {
    background: ${COLORS.backgroundLight};
    border-radius: 10px;
  }

  &::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 10px;
  }

  @media (max-width: 1024px) {
    width: 100%;
    height: auto;
    margin-bottom: 1rem;
  }
`;

const AdminButton = styled.button`
  width: 100%;
  padding: 1rem;
  background: ${GRADIENTS.primary};
  color: white;
  border: none;
  border-radius: 10px;
  font-weight: 600;
  cursor: pointer;
  margin-bottom: 1.5rem;
  transition: all 0.3s ease;
  font-size: 1rem;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(255, 69, 0, 0.3);
  }
`;

const UserInfo = styled.div`
  background: white;
  padding: 1rem;
  border-radius: 10px;
  margin-bottom: 1.5rem;
  text-align: center;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
`;

const UserEmail = styled.div`
  font-weight: 600;
  color: ${COLORS.text};
  margin-bottom: 0.5rem;
`;

const AdminBadge = styled.div`
  display: inline-block;
  background: ${GRADIENTS.primary};
  color: white;
  padding: 0.25rem 0.75rem;
  border-radius: 20px;
  font-size: 0.8rem;
  font-weight: 600;
`;

const Sidebar = ({ onAdminClick }) => {
  const { user, isAdmin } = useAuth();
  const { sendMessage } = useChat();

  const handleFAQClick = (question) => {
    sendMessage(question);
  };

  return (
    <SidebarContainer>
      {isAdmin && (
        <>
          <UserInfo>
            <UserEmail>{user}</UserEmail>
            <AdminBadge>Admin Access</AdminBadge>
          </UserInfo>
          <AdminButton onClick={onAdminClick}>
            🔧 Admin Panel
          </AdminButton>
        </>
      )}
      
      <FAQList onQuestionClick={handleFAQClick} />
      <FeedbackStats />
    </SidebarContainer>
  );
};

export default Sidebar;