import { useState, useEffect } from 'react';
import styled from 'styled-components';
import { chatService } from '../../services/chatService';
import { COLORS, GRADIENTS } from '../../utils/constants';

const FAQContainer = styled.div`
  margin-bottom: 2rem;
`;

const FAQHeader = styled.h3`
  color: ${COLORS.text};
  margin-bottom: 1rem;
  font-size: 1.2rem;
`;

const FAQItem = styled.button`
  width: 100%;
  background: linear-gradient(135deg, #ffff 80%, #FF4500 100%);
  border: none;
  border-radius: 10px;
  padding: 0.75rem;
  margin-bottom: 0.5rem;
  text-align: left;
  cursor: pointer;
  transition: all 0.3s ease;
  border-left: 4px solid #f4a460;
  color: ${COLORS.textLight};
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);

  &:hover {
    transform: translateX(5px);
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
    border-left-color: #764ba2;
    background-color: white;
    color: darkorange;
  }

  &:active {
    transform: translateX(3px);
  }
`;

const QuestionText = styled.div`
  font-weight: 500;
  margin-bottom: 0.25rem;
  font-size: 0.9rem;
`;

const QuestionCount = styled.div`
  font-size: 0.75rem;
  opacity: 0.8;
`;

const LoadingText = styled.div`
  color: ${COLORS.textLight};
  font-style: italic;
  padding: 1rem;
  text-align: center;
`;

const ErrorText = styled.div`
  color: ${COLORS.error};
  padding: 1rem;
  text-align: center;
  font-size: 0.9rem;
`;

const FAQList = ({ onQuestionClick }) => {
  const [faqs, setFaqs] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadFAQs();
  }, []);

  const loadFAQs = async () => {
    try {
      setLoading(true);
      const data = await chatService.getFAQs();
      setFaqs(data);
      setError(null);
    } catch (err) {
      setError('Failed to load FAQs');
      console.error('Error loading FAQs:', err);
    } finally {
      setLoading(false);
    }
  };

  const truncateQuestion = (question, maxLength = 75) => {
    if (question.length <= maxLength) return question;
    return question.substring(0, maxLength) + '...';
  };

  if (loading) {
    return (
      <FAQContainer>
        <FAQHeader>FAQs</FAQHeader>
        <LoadingText>Loading FAQs...</LoadingText>
      </FAQContainer>
    );
  }

  if (error) {
    return (
      <FAQContainer>
        <FAQHeader>FAQs</FAQHeader>
        <ErrorText>{error}</ErrorText>
      </FAQContainer>
    );
  }

  const faqEntries = Object.entries(faqs);

  if (faqEntries.length === 0) {
    return (
      <FAQContainer>
        <FAQHeader>FAQs</FAQHeader>
        <LoadingText>No FAQs available</LoadingText>
      </FAQContainer>
    );
  }

  return (
    <FAQContainer>
      <FAQHeader>FAQs</FAQHeader>
      {faqEntries.map(([question, count], index) => (
        <FAQItem 
          key={index} 
          onClick={() => onQuestionClick(question)}
          title={question}
        >
          <QuestionText>Q: {truncateQuestion(question)}</QuestionText>
          <QuestionCount>(Asked {count} times)</QuestionCount>
        </FAQItem>
      ))}
    </FAQContainer>
  );
};

export default FAQList;