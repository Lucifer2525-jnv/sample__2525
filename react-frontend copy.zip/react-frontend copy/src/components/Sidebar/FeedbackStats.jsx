import { useState } from 'react';
import styled from 'styled-components';
import { chatService } from '../../services/chatService';
import { COLORS, GRADIENTS } from '../../utils/constants';

const StatsContainer = styled.div`
  background: ${GRADIENTS.success};
  padding: 1rem;
  border-radius: 10px;
  margin-bottom: 1.5rem;
`;

const StatsHeader = styled.h3`
  color: ${COLORS.text};
  margin-bottom: 1rem;
  font-size: 1.1rem;
`;

const ButtonGroup = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 0.5rem;
  margin-bottom: 1rem;
`;

const StatsButton = styled.button`
  padding: 0.5rem;
  background: white;
  border: 2px solid ${COLORS.border};
  border-radius: 8px;
  cursor: pointer;
  font-weight: 600;
  font-size: 0.85rem;
  transition: all 0.3s ease;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    border-color: ${COLORS.primary};
  }
`;

const QuickStats = styled.div`
  margin-top: 1rem;
`;

const StatCard = styled.div`
  background: white;
  border-radius: 10px;
  padding: 1rem;
  margin-bottom: 0.75rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  text-align: center;
`;

const StatValue = styled.div`
  font-size: 1.8rem;
  font-weight: 700;
  color: ${props => props.color || COLORS.secondary};
  margin-bottom: 0.25rem;
`;

const StatLabel = styled.div`
  font-size: 0.85rem;
  color: ${COLORS.textLight};
`;

const FeedbackHistory = styled.div`
  margin-top: 1rem;
`;

const FeedbackItem = styled.div`
  background: white;
  border-radius: 8px;
  padding: 0.75rem;
  margin-bottom: 0.5rem;
  font-size: 0.85rem;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.08);
`;

const FeedbackDate = styled.div`
  color: ${COLORS.textLight};
  font-size: 0.75rem;
  margin-bottom: 0.25rem;
`;

const FeedbackRating = styled.div`
  color: ${COLORS.primary};
  font-weight: 600;
`;

const FeedbackText = styled.div`
  color: ${COLORS.text};
  margin-top: 0.25rem;
  font-size: 0.8rem;
`;

const LoadingText = styled.div`
  color: ${COLORS.textLight};
  font-style: italic;
  padding: 1rem;
  text-align: center;
`;

const InfoText = styled.div`
  color: ${COLORS.textLight};
  font-size: 0.85rem;
  padding: 1rem;
  text-align: center;
`;

const FeedbackStats = () => {
  const [stats, setStats] = useState(null);
  const [myFeedback, setMyFeedback] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showHistory, setShowHistory] = useState(false);

  const loadStats = async () => {
    setLoading(true);
    try {
      const data = await chatService.getFeedbackStats();
      setStats(data);
    } catch (error) {
      console.error('Failed to load stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadMyFeedback = async () => {
    setLoading(true);
    try {
      const data = await chatService.getMyFeedback();
      setMyFeedback(data);
      setShowHistory(true);
    } catch (error) {
      console.error('Failed to load feedback:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <StatsContainer>
      <StatsHeader>Feedback & Stats</StatsHeader>
      
      <ButtonGroup>
        <StatsButton onClick={loadMyFeedback}>
          📝 My Feedback
        </StatsButton>
        <StatsButton onClick={loadStats}>
          📈 Overall Stats
        </StatsButton>
      </ButtonGroup>

      {loading && <LoadingText>Loading...</LoadingText>}

      {stats && !showHistory && (
        <QuickStats>
          <StatCard>
            <StatValue color={COLORS.secondary}>
              {stats.total_feedback || 0}
            </StatValue>
            <StatLabel>Total Feedback</StatLabel>
          </StatCard>

          <StatCard>
            <StatValue color={COLORS.success}>
              {stats.helpfulness_rate?.toFixed(1) || 0}%
            </StatValue>
            <StatLabel>Helpful Rate</StatLabel>
          </StatCard>

          {stats.average_rating && (
            <StatCard>
              <StatValue color={COLORS.warning}>
                {stats.average_rating.toFixed(1)}/5 ⭐
              </StatValue>
              <StatLabel>Average Rating</StatLabel>
            </StatCard>
          )}
        </QuickStats>
      )}

      {showHistory && myFeedback && (
        <FeedbackHistory>
          <StatLabel style={{ marginBottom: '0.75rem', textAlign: 'center' }}>
            Recent Feedback ({myFeedback.total_count || 0})
          </StatLabel>
          
          {myFeedback.feedback_history?.length > 0 ? (
            myFeedback.feedback_history.slice(0, 3).map((feedback, index) => (
              <FeedbackItem key={index}>
                <FeedbackDate>
                  {new Date(feedback.timestamp).toLocaleDateString()}
                </FeedbackDate>
                {feedback.rating && (
                  <FeedbackRating>
                    ⭐ Rating: {feedback.rating}/5
                  </FeedbackRating>
                )}
                <div style={{ fontSize: '0.8rem', marginTop: '0.25rem' }}>
                  👍 {feedback.is_helpful ? 'Helpful' : feedback.is_helpful === false ? 'Not Helpful' : 'N/A'}
                </div>
                {feedback.feedback_text && (
                  <FeedbackText>
                    💬 {feedback.feedback_text.substring(0, 100)}
                    {feedback.feedback_text.length > 100 ? '...' : ''}
                  </FeedbackText>
                )}
              </FeedbackItem>
            ))
          ) : (
            <InfoText>
              💡 No feedback history yet. Start giving feedback!
            </InfoText>
          )}
        </FeedbackHistory>
      )}

      {!stats && !showHistory && !loading && (
        <InfoText>
          💡 Click buttons above to view stats!
        </InfoText>
      )}
    </StatsContainer>
  );
};

export default FeedbackStats;