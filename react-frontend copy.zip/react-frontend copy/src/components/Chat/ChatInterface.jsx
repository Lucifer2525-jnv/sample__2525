import { useEffect, useRef } from 'react';
import styled from 'styled-components';
import { useChat } from '../../context/ChatContext';
import ChatMessage from './ChatMessage';
import ChatInput from './ChatInput';
import FeedbackForm from './FeedbackForm';
import { COLORS } from '../../utils/constants';

const ChatContainer = styled.div`
  display: flex;
  flex-direction: column;
  height: calc(100vh - 200px);
  background: white;
  border-radius: 15px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
  overflow: hidden;
`;

const MessagesContainer = styled.div`
  flex: 1;
  overflow-y: auto;
  padding: 2rem;
  
  &::-webkit-scrollbar {
    width: 8px;
  }

  &::-webkit-scrollbar-track {
    background: ${COLORS.backgroundLight};
    border-radius: 10px;
  }

  &::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 10px;
  }

  &::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
  }
`;

const WelcomeMessage = styled.div`
  text-align: center;
  padding: 3rem 2rem;
`;

const WelcomeTitle = styled.h2`
  font-size: 2rem;
  color: ${COLORS.text};
  margin-bottom: 1rem;
`;

const WelcomeSubtitle = styled.p`
  color: ${COLORS.textLight};
  font-size: 1.1rem;
  margin-bottom: 2rem;
`;

const WelcomeNote = styled.div`
  background: linear-gradient(135deg, #e8f5e8 100%, #d4edda 50%);
  padding: 1rem;
  border-radius: 10px;
  color: ${COLORS.text};
  font-size: 0.9rem;
`;

const LoadingIndicator = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 1rem;
  color: ${COLORS.textLight};
  font-style: italic;

  &::after {
    content: '...';
    animation: dots 1.5s steps(4, end) infinite;
  }

  @keyframes dots {
    0%, 20% { content: '.'; }
    40% { content: '..'; }
    60%, 100% { content: '...'; }
  }
`;

const ErrorMessage = styled.div`
  background: #fee;
  color: ${COLORS.error};
  padding: 1rem;
  border-radius: 10px;
  margin: 1rem 0;
  border-left: 4px solid ${COLORS.error};
`;

const MessageWrapper = styled.div`
  margin-bottom: 1rem;
`;

const ChatInterface = () => {
  const { messages, loading, error, sendMessage } = useChat();
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (message) => {
    await sendMessage(message);
  };

  return (
    <ChatContainer>
      <MessagesContainer>
        {messages.length === 0 ? (
          <WelcomeMessage>
            <WelcomeTitle>Hello! What are you looking for</WelcomeTitle>
            <WelcomeSubtitle>
              Ask questions related to ARB process, Platform Provisioning
            </WelcomeSubtitle>
            <WelcomeNote>
              💡 <strong>Note:</strong> Ask Questions related to ARB Process, Platform Provisioning
            </WelcomeNote>
          </WelcomeMessage>
        ) : (
          <>
            {messages.map((message, index) => (
              <MessageWrapper key={index}>
                <ChatMessage 
                  message={message} 
                  isUser={message.role === 'user'} 
                />
                {message.role === 'assistant' && message.response_id && (
                  <FeedbackForm responseId={message.response_id} />
                )}
              </MessageWrapper>
            ))}
            {loading && (
              <LoadingIndicator>
                ARB Chatbot is Generating Response
              </LoadingIndicator>
            )}
            {error && (
              <ErrorMessage>
                ❌ Error: {error}
              </ErrorMessage>
            )}
          </>
        )}
        <div ref={messagesEndRef} />
      </MessagesContainer>
      
      <ChatInput 
        onSend={handleSendMessage} 
        disabled={loading}
        placeholder="Type your question here"
      />
    </ChatContainer>
  );
};

export default ChatInterface;