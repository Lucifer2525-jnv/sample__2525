import { useState } from 'react';
import styled from 'styled-components';
import { COLORS, GRADIENTS } from '../../utils/constants';

const InputContainer = styled.div`
  position: sticky;
  bottom: 0;
  background: white;
  padding: 1rem;
  border-top: 2px solid ${COLORS.border};
  box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.05);
`;

const InputForm = styled.form`
  display: flex;
  gap: 0.5rem;
  max-width: 1200px;
  margin: 0 auto;
`;

const Input = styled.input`
  flex: 1;
  padding: 1rem 1.5rem;
  border: 2px solid ${COLORS.border};
  border-radius: 25px;
  font-size: 1rem;
  transition: all 0.3s ease;

  &:focus {
    outline: none;
    border-color: ${COLORS.primary};
    box-shadow: 0 0 0 3px rgba(255, 165, 0, 0.1);
  }

  &:disabled {
    background: ${COLORS.backgroundLight};
    cursor: not-allowed;
  }
`;

const SendButton = styled.button`
  padding: 1rem 2rem;
  background: ${GRADIENTS.primary};
  color: white;
  border: none;
  border-radius: 25px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  gap: 0.5rem;

  &:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(255, 69, 0, 0.3);
  }

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
  }
`;

const ChatInput = ({ onSend, disabled, placeholder = "What's on your mind?" }) => {
  const [message, setMessage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (message.trim() && !disabled) {
      onSend(message.trim());
      setMessage('');
    }
  };

  return (
    <InputContainer>
      <InputForm onSubmit={handleSubmit}>
        <Input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder={placeholder}
          disabled={disabled}
        />
        <SendButton type="submit" disabled={disabled || !message.trim()}>
          <span>Send</span>
          <span>▶</span>
        </SendButton>
      </InputForm>
    </InputContainer>
  );
};

export default ChatInput;