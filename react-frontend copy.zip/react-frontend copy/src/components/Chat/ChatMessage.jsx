import styled from 'styled-components';
import { COLORS } from '../../utils/constants';

const MessageContainer = styled.div`
  display: flex;
  flex-direction: column;
  margin-bottom: 1.5rem;
  animation: fadeInUp 0.3s ease;

  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(10px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
`;

const MessageBubble = styled.div`
  background: ${props => props.isUser ? 'linear-gradient(135deg, #FFA500 0%, #FF4500 100%)' : 'white'};
  color: ${props => props.isUser ? 'white' : COLORS.text};
  padding: 1rem 1.5rem;
  border-radius: 15px;
  max-width: 80%;
  align-self: ${props => props.isUser ? 'flex-end' : 'flex-start'};
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  word-wrap: break-word;
  transition: all 0.3s ease;

  &:hover {
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
  }
`;

const MessageContent = styled.div`
  line-height: 1.6;
  white-space: pre-wrap;
`;

const Timestamp = styled.div`
  font-size: 0.75rem;
  color: ${COLORS.textLight};
  margin-top: 0.5rem;
  align-self: ${props => props.isUser ? 'flex-end' : 'flex-start'};
  font-style: italic;
`;

const CitationsSection = styled.div`
  margin-top: 1rem;
  padding-top: 1rem;
  border-top: 1px solid ${COLORS.border};
`;

const SectionTitle = styled.div`
  font-weight: 600;
  margin-bottom: 0.5rem;
  color: ${COLORS.text};
`;

const CitationLink = styled.a`
  display: block;
  color: ${COLORS.primary};
  text-decoration: none;
  margin-bottom: 0.25rem;
  transition: all 0.2s ease;

  &:hover {
    color: ${COLORS.primaryDark};
    transform: translateX(5px);
  }
`;

const FollowUpList = styled.ol`
  margin: 0.5rem 0 0 1.5rem;
  padding: 0;
`;

const FollowUpItem = styled.li`
  margin-bottom: 0.5rem;
  color: ${COLORS.text};
`;

const ChatMessage = ({ message, isUser }) => {
  const formatTime = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  const renderContent = () => {
    if (isUser) {
      return <MessageContent>{message.content}</MessageContent>;
    }

    const content = message.content;
    const answer = typeof content === 'string' ? content : content.answer;
    const citations = content.citation || [];
    const followUps = content.follow_up || [];

    return (
      <>
        <MessageContent>{answer}</MessageContent>
        
        {citations.length > 0 && (
          <CitationsSection>
            <SectionTitle>📚 Citations:</SectionTitle>
            {citations.map((citation, index) => (
              <CitationLink 
                key={index} 
                href={citation} 
                target="_blank" 
                rel="noopener noreferrer"
              >
                - Reference {index + 1}
              </CitationLink>
            ))}
          </CitationsSection>
        )}

        {followUps.length > 0 && (
          <CitationsSection>
            <SectionTitle>💡 Follow Up:</SectionTitle>
            <FollowUpList>
              {followUps.map((followUp, index) => (
                <FollowUpItem key={index}>{followUp}</FollowUpItem>
              ))}
            </FollowUpList>
          </CitationsSection>
        )}
      </>
    );
  };

  return (
    <MessageContainer>
      <MessageBubble isUser={isUser}>
        {renderContent()}
      </MessageBubble>
      <Timestamp isUser={isUser}>
        {formatTime(message.timestamp)}
      </Timestamp>
    </MessageContainer>
  );
};

export default ChatMessage;