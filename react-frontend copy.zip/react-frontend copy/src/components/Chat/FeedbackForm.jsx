import { useState } from 'react';
import styled from 'styled-components';
import { chatService } from '../../services/chatService';
import { COLORS, GRADIENTS } from '../../utils/constants';

const FeedbackContainer = styled.div`
  margin-top: 1rem;
  padding: 1rem;
  background: ${COLORS.backgroundLight};
  border-radius: 10px;
`;

const FeedbackQuestion = styled.div`
  font-weight: 600;
  margin-bottom: 0.75rem;
  color: ${COLORS.text};
`;

const ButtonGroup = styled.div`
  display: flex;
  gap: 0.5rem;
  margin-bottom: 1rem;
`;

const FeedbackButton = styled.button`
  padding: 0.5rem 1rem;
  border: 2px solid ${COLORS.border};
  border-radius: 8px;
  background: white;
  cursor: pointer;
  transition: all 0.3s ease;
  font-weight: 600;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    border-color: ${COLORS.primary};
  }
`;

const SuccessMessage = styled.div`
  background: ${COLORS.success};
  color: white;
  padding: 0.75rem;
  border-radius: 8px;
  text-align: center;
  font-weight: 600;
`;

const DetailedFeedbackSection = styled.div`
  margin-top: 1rem;
  padding: 1rem;
  background: white;
  border-radius: 10px;
  border: 2px solid ${COLORS.border};
`;

const Label = styled.label`
  display: block;
  font-weight: 600;
  margin-bottom: 0.5rem;
  color: ${COLORS.text};
`;

const Select = styled.select`
  width: 100%;
  padding: 0.75rem;
  border: 2px solid ${COLORS.border};
  border-radius: 8px;
  margin-bottom: 1rem;
  font-size: 1rem;

  &:focus {
    outline: none;
    border-color: ${COLORS.primary};
  }
`;

const TextArea = styled.textarea`
  width: 100%;
  padding: 0.75rem;
  border: 2px solid ${COLORS.border};
  border-radius: 8px;
  margin-bottom: 1rem;
  font-size: 1rem;
  min-height: 100px;
  resize: vertical;
  box-sizing: border-box;

  &:focus {
    outline: none;
    border-color: ${COLORS.primary};
  }
`;

const RatingSlider = styled.input`
  width: 100%;
  margin-bottom: 1rem;
`;

const RatingDisplay = styled.div`
  text-align: center;
  font-size: 1.5rem;
  margin-bottom: 1rem;
  color: ${COLORS.primary};
`;

const CheckboxGroup = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 0.5rem;
  margin-bottom: 1rem;
`;

const CheckboxLabel = styled.label`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  cursor: pointer;
`;

const SubmitButton = styled.button`
  width: 100%;
  padding: 0.75rem;
  background: ${GRADIENTS.primary};
  color: white;
  border: none;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(255, 69, 0, 0.3);
  }

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`;

const ToggleButton = styled.button`
  background: none;
  border: none;
  color: ${COLORS.primary};
  cursor: pointer;
  text-decoration: underline;
  margin-top: 0.5rem;
  font-size: 0.9rem;

  &:hover {
    color: ${COLORS.primaryDark};
  }
`;

const FeedbackForm = ({ responseId, onSubmitSuccess }) => {
  const [submitted, setSubmitted] = useState(false);
  const [showDetailed, setShowDetailed] = useState(false);
  const [loading, setLoading] = useState(false);
  
  // Form state
  const [rating, setRating] = useState(3);
  const [feedbackCategory, setFeedbackCategory] = useState('');
  const [feedbackText, setFeedbackText] = useState('');
  const [isAccurate, setIsAccurate] = useState(false);
  const [isRelevant, setIsRelevant] = useState(false);
  const [isClear, setIsClear] = useState(false);
  const [isComplete, setIsComplete] = useState(false);

  const handleQuickFeedback = async (isHelpful) => {
    setLoading(true);
    try {
      await chatService.submitFeedback({
        response_id: responseId,
        is_helpful: isHelpful,
      });
      setSubmitted(true);
      if (onSubmitSuccess) onSubmitSuccess();
    } catch (error) {
      console.error('Failed to submit feedback:', error);
      alert('Failed to submit feedback. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleDetailedSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      await chatService.submitFeedback({
        response_id: responseId,
        rating,
        feedback_category: feedbackCategory || null,
        feedback_text: feedbackText || null,
        is_accurate: isAccurate,
        is_relevant: isRelevant,
        is_clear: isClear,
        is_complete: isComplete,
      });
      setSubmitted(true);
      if (onSubmitSuccess) onSubmitSuccess();
    } catch (error) {
      console.error('Failed to submit feedback:', error);
      alert('Failed to submit feedback. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <FeedbackContainer>
        <SuccessMessage>✅ Feedback submitted! Thank you!</SuccessMessage>
      </FeedbackContainer>
    );
  }

  return (
    <FeedbackContainer>
      <FeedbackQuestion>Was this response helpful?</FeedbackQuestion>
      
      <ButtonGroup>
        <FeedbackButton onClick={() => handleQuickFeedback(true)} disabled={loading}>
          👍 Helpful
        </FeedbackButton>
        <FeedbackButton onClick={() => handleQuickFeedback(false)} disabled={loading}>
          👎 Not Helpful
        </FeedbackButton>
      </ButtonGroup>

      <ToggleButton onClick={() => setShowDetailed(!showDetailed)}>
        {showDetailed ? '▼ Hide' : '▶'} Provide detailed feedback (optional)
      </ToggleButton>

      {showDetailed && (
        <DetailedFeedbackSection>
          <form onSubmit={handleDetailedSubmit}>
            <Label>Rate this response (1-5 stars)</Label>
            <RatingDisplay>{'⭐'.repeat(rating)}</RatingDisplay>
            <RatingSlider
              type="range"
              min="1"
              max="5"
              value={rating}
              onChange={(e) => setRating(parseInt(e.target.value))}
            />

            <Label>What aspect needs improvement?</Label>
            <Select
              value={feedbackCategory}
              onChange={(e) => setFeedbackCategory(e.target.value)}
            >
              <option value="">Select (optional)</option>
              <option value="accuracy">Accuracy</option>
              <option value="helpfulness">Helpfulness</option>
              <option value="clarity">Clarity</option>
              <option value="completeness">Completeness</option>
              <option value="relevance">Relevance</option>
              <option value="other">Other</option>
            </Select>

            <Label>Additional comments</Label>
            <TextArea
              placeholder="Tell us how we can improve..."
              value={feedbackText}
              onChange={(e) => setFeedbackText(e.target.value)}
            />

            <Label>Response quality</Label>
            <CheckboxGroup>
              <CheckboxLabel>
                <input
                  type="checkbox"
                  checked={isAccurate}
                  onChange={(e) => setIsAccurate(e.target.checked)}
                />
                Accurate
              </CheckboxLabel>
              <CheckboxLabel>
                <input
                  type="checkbox"
                  checked={isRelevant}
                  onChange={(e) => setIsRelevant(e.target.checked)}
                />
                Relevant
              </CheckboxLabel>
              <CheckboxLabel>
                <input
                  type="checkbox"
                  checked={isClear}
                  onChange={(e) => setIsClear(e.target.checked)}
                />
                Clear
              </CheckboxLabel>
              <CheckboxLabel>
                <input
                  type="checkbox"
                  checked={isComplete}
                  onChange={(e) => setIsComplete(e.target.checked)}
                />
                Complete
              </CheckboxLabel>
            </CheckboxGroup>

            <SubmitButton type="submit" disabled={loading}>
              {loading ? 'Submitting...' : 'Submit Detailed Feedback'}
            </SubmitButton>
          </form>
        </DetailedFeedbackSection>
      )}
    </FeedbackContainer>
  );
};

export default FeedbackForm;