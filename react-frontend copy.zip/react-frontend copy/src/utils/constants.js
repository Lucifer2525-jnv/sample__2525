export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

export const COLORS = {
  primary: '#FFA500',
  primaryDark: '#FF4500',
  secondary: '#667eea',
  secondaryDark: '#764ba2',
  success: '#2ecc71',
  error: '#e74c3c',
  warning: '#f39c12',
  info: '#3498db',
  text: '#2c3e50',
  textLight: '#7f8c8d',
  background: '#f8f9fa',
  backgroundLight: '#e9ecef',
  white: '#ffffff',
  border: '#dee2e6',
};

export const GRADIENTS = {
  primary: 'linear-gradient(135deg, #FFA500 0%, #FF4500 100%)',
  secondary: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
  light: 'linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%)',
  success: 'linear-gradient(135deg, #e8f5e8 100%, #d4edda 50%)',
};

export const ENDPOINTS = {
  // Auth
  VALIDATE_TOKEN: '/sso/validate-token',
  
  // Chat
  SESSIONS: '/sessions',
  CHAT: '/chat',
  FAQ: '/faq',
  
  // Feedback
  FEEDBACK: '/chatbot/feedback',
  FEEDBACK_STATS: '/chatbot/feedback/stats',
  MY_FEEDBACK: '/chatbot/feedback/my-feedback',
  
  // System
  HEALTH: '/health',
  SYSTEM_STATUS: '/chatbot/system/status',
  
  // Admin
  ADMIN_DOCUMENTS: '/admin/documents',
  ADMIN_DOCUMENT_BY_ID: (id) => `/admin/documents/${id}`,
  ADMIN_DOCUMENT_STATUS: (id) => `/admin/documents/${id}/status`,
  ADMIN_DOCUMENT_TOGGLE: (id) => `/admin/documents/${id}/toggle-active`,
  ADMIN_DOCUMENT_ADD: '/admin/documents/add',
  ADMIN_DOCUMENT_DELETE: (id) => `/admin/documents/${id}`,
  ADMIN_PROCESS_OWNERS: '/admin/process-owners',
  ADMIN_PROCESS_OWNER_BY_ID: (id) => `/admin/process-owners/${id}`,
  ADMIN_SAFETY_LOGS: '/admin/safety-logs',
  ADMIN_SESSIONS: '/admin/sessions',
  ADMIN_PERMISSIONS: '/admin/permissions',
};