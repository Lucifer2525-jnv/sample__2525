import { useState } from 'react';
import styled, { createGlobalStyle } from 'styled-components';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ChatProvider } from './context/ChatContext';
import Login from './components/Auth/Login';
import Header from './components/Header/Header';
import ChatInterface from './components/Chat/ChatInterface';
import Sidebar from './components/Sidebar/Sidebar';
import AdminPanel from './components/Admin/AdminPanel';
import { COLORS, GRADIENTS } from './utils/constants';

const GlobalStyle = createGlobalStyle`
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
      'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
      sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    background: ${GRADIENTS.light};
  }

  code {
    font-family: source-code-pro, Menlo, Monaco, Consolas, 'Courier New',
      monospace;
  }
`;

const AppContainer = styled.div`
  min-height: 100vh;
  padding: 1rem;
`;

const MainLayout = styled.div`
  display: flex;
  gap: 1rem;
  max-width: 1600px;
  margin: 0 auto;

  @media (max-width: 1024px) {
    flex-direction: column;
  }
`;

const MainContent = styled.main`
  flex: 1;
  min-width: 0;
`;

const LoadingContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  font-size: 1.5rem;
  color: ${COLORS.textLight};
`;

function AppContent() {
  const { isAuthenticated, loading } = useAuth();
  const [showAdmin, setShowAdmin] = useState(false);

  if (loading) {
    return <LoadingContainer>Loading...</LoadingContainer>;
  }

  if (!isAuthenticated) {
    return <Login />;
  }

  if (showAdmin) {
    return (
      <AppContainer>
        <AdminPanel onBack={() => setShowAdmin(false)} />
      </AppContainer>
    );
  }

  return (
    <ChatProvider>
      <AppContainer>
        <Header />
        <MainLayout>
          <Sidebar onAdminClick={() => setShowAdmin(true)} />
          <MainContent>
            <ChatInterface />
          </MainContent>
        </MainLayout>
      </AppContainer>
    </ChatProvider>
  );
}

function App() {
  return (
    <AuthProvider>
      <GlobalStyle />
      <AppContent />
    </AuthProvider>
  );
}

export default App;
