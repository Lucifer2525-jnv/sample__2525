import { createContext, useContext, useState, useEffect } from 'react';
import { chatService } from '../services/chatService';

const ChatContext = createContext(null);

export const ChatProvider = ({ children }) => {
  const [sessionId, setSessionId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Create new session on mount
  useEffect(() => {
    createNewSession();
  }, []);

  const createNewSession = async () => {
    try {
      setLoading(true);
      const response = await chatService.createSession();
      setSessionId(response.session_id);
      setMessages([]);
      setError(null);
    } catch (err) {
      setError(err);
      console.error('Failed to create session:', err);
    } finally {
      setLoading(false);
    }
  };

  const sendMessage = async (message) => {
    if (!sessionId) {
      setError('No active session');
      return;
    }

    // Add user message to chat
    const userMessage = {
      role: 'user',
      content: message,
      timestamp: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, userMessage]);

    try {
      setLoading(true);
      setError(null);
      
      const response = await chatService.sendMessage(message, sessionId);
      
      // Parse response if it's JSON string
      let parsedResponse;
      try {
        parsedResponse = JSON.parse(response.response);
      } catch {
        parsedResponse = {
          answer: response.response,
          citation: [],
          follow_up: [],
        };
      }

      // Add assistant message to chat
      const assistantMessage = {
        role: 'assistant',
        content: parsedResponse,
        timestamp: new Date().toISOString(),
        response_id: response.response_id,
      };
      setMessages((prev) => [...prev, assistantMessage]);
      
      return assistantMessage;
    } catch (err) {
      setError(err);
      console.error('Failed to send message:', err);
      
      // Add error message
      const errorMessage = {
        role: 'assistant',
        content: { answer: 'Sorry, I encountered an error. Please try again.', citation: [], follow_up: [] },
        timestamp: new Date().toISOString(),
        isError: true,
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  const clearSession = () => {
    setMessages([]);
  };

  const value = {
    sessionId,
    messages,
    loading,
    error,
    sendMessage,
    createNewSession,
    clearSession,
  };

  return <ChatContext.Provider value={value}>{children}</ChatContext.Provider>;
};

export const useChat = () => {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChat must be used within ChatProvider');
  }
  return context;
};