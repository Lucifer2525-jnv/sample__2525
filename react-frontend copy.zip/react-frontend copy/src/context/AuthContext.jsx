import { createContext, useContext, useState, useEffect } from 'react';
import { authService } from '../services/authService';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    // Check if token exists on mount
    const token = authService.getToken();
    if (token) {
      validateToken(token);
    } else {
      setLoading(false);
    }
  }, []);

  const validateToken = async (token) => {
    setLoading(true);
    const result = await authService.validateToken(token);
    
    if (result.success) {
      setIsAuthenticated(true);
      setUser(result.data.user);
      // Check if user is admin (you can modify this logic based on your needs)
      setIsAdmin(result.data.user?.includes('admin') || false);
    } else {
      authService.removeToken();
      setIsAuthenticated(false);
      setUser(null);
      setIsAdmin(false);
    }
    setLoading(false);
  };

  const login = async (token) => {
    authService.setToken(token);
    await validateToken(token);
  };

  const logout = () => {
    authService.removeToken();
    setIsAuthenticated(false);
    setUser(null);
    setIsAdmin(false);
  };

  const value = {
    isAuthenticated,
    user,
    loading,
    isAdmin,
    login,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};