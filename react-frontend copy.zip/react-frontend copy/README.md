# GSK EAI Chatbot - React Frontend

A modern React-based frontend for the GSK EAI Chatbot, built with Vite and styled-components.

## Features

### User Features
- 💬 **Chat Interface**: Real-time chat with the ARB Chatbot
- 📝 **Feedback System**: Simple thumbs up/down and detailed feedback forms
- ❓ **FAQ Sidebar**: Quick access to frequently asked questions
- 📊 **Feedback Stats**: View personal feedback history and overall statistics
- 🔄 **Session Management**: Create new sessions or clear current session
- 🎨 **Modern UI**: Orange gradient design (#FFA500 to #FF4500) with smooth animations

### Admin Features (Admin Users Only)
- 📄 **Document Management**: View, filter, toggle active status, and delete documents
- ➕ **Add Documents**: Submit new documents for indexing (Confluence or VQD)
- 📋 **Process Owners**: Manage process owners with full CRUD operations
- 🛡️ **Safety Logs**: Monitor content safety events and PII detection
- 📈 **Statistics**: View document stats and filtering options

## Tech Stack

- **React 18** - UI library
- **Vite** - Build tool and dev server
- **Styled Components** - CSS-in-JS styling
- **Axios** - HTTP client
- **Context API** - State management

## Prerequisites

- Node.js 18.20.5 or higher
- npm or yarn
- Running FastAPI backend on `http://localhost:8000`

## Installation

1. Navigate to the project directory:
```bash
cd react-frontend
```

2. Install dependencies:
```bash
npm install
```

3. Configure environment variables:
Create a `.env` file in the root directory:
```env
VITE_API_BASE_URL=http://localhost:8000
```

## Running the Application

### Development Mode
```bash
npm run dev
```
The application will be available at `http://localhost:5173`

### Build for Production
```bash
npm run build
```

### Preview Production Build
```bash
npm run preview
```

## Authentication

The application uses SSO token-based authentication:

1. On first load, you'll see a login screen
2. Paste your SSO access token in the input field
3. Click "Login" to authenticate
4. The token is stored in localStorage for persistence

**Note**: For now, the access token must be manually obtained and pasted. Contact your administrator for assistance.

## Project Structure

```
react-frontend/
├── public/                 # Static assets
├── src/
│   ├── components/        # React components
│   │   ├── Admin/        # Admin panel components
│   │   │   ├── AdminPanel.jsx
│   │   │   ├── DocumentManagement.jsx
│   │   │   ├── AddDocument.jsx
│   │   │   ├── ProcessOwners.jsx
│   │   │   └── SafetyLogs.jsx
│   │   ├── Auth/         # Authentication components
│   │   │   └── Login.jsx
│   │   ├── Chat/         # Chat interface components
│   │   │   ├── ChatInterface.jsx
│   │   │   ├── ChatMessage.jsx
│   │   │   ├── ChatInput.jsx
│   │   │   └── FeedbackForm.jsx
│   │   ├── Header/       # Header component
│   │   │   └── Header.jsx
│   │   └── Sidebar/      # Sidebar components
│   │       ├── Sidebar.jsx
│   │       ├── FAQList.jsx
│   │       └── FeedbackStats.jsx
│   ├── context/          # React Context providers
│   │   ├── AuthContext.jsx
│   │   └── ChatContext.jsx
│   ├── services/         # API service layer
│   │   ├── api.js
│   │   ├── authService.js
│   │   ├── chatService.js
│   │   └── adminService.js
│   ├── utils/            # Utility functions and constants
│   │   └── constants.js
│   ├── App.jsx           # Main App component
│   └── main.jsx          # Entry point
├── .env                  # Environment variables
├── package.json          # Dependencies
└── vite.config.js        # Vite configuration
```

## API Integration

The frontend integrates with the following backend endpoints:

### Authentication
- `GET /sso/validate-token` - Validate SSO token

### Chat
- `POST /sessions` - Create new chat session
- `POST /chat` - Send chat message
- `GET /faq` - Get FAQs

### Feedback
- `POST /chatbot/feedback` - Submit feedback
- `GET /chatbot/feedback/stats` - Get feedback statistics
- `GET /chatbot/feedback/my-feedback` - Get user's feedback history

### Admin (Requires Admin Access)
- `GET /admin/documents` - Get documents with filters
- `PUT /admin/documents/{id}/toggle-active` - Toggle document active status
- `DELETE /admin/documents/{id}` - Delete document
- `POST /admin/documents/add` - Add new document
- `GET /admin/process-owners` - Get process owners
- `POST /admin/process-owners` - Add process owner
- `DELETE /admin/process-owners/{id}` - Delete process owner
- `GET /admin/safety-logs` - Get safety logs

## Design System

### Colors
- **Primary**: #FFA500 (Orange)
- **Primary Dark**: #FF4500 (Orange Red)
- **Secondary**: #667eea (Purple)
- **Success**: #2ecc71 (Green)
- **Error**: #e74c3c (Red)
- **Warning**: #f39c12 (Yellow)

### Gradients
- **Primary**: Linear gradient from #FFA500 to #FF4500
- **Secondary**: Linear gradient from #667eea to #764ba2

## Features in Detail

### Chat Interface
- Real-time messaging with the chatbot
- Message history with timestamps
- Citations and follow-up questions display
- Feedback forms for each response
- Auto-scroll to latest message

### Admin Panel
- **Documents Tab**: Manage indexed documents with filtering and pagination
- **Safety Logs Tab**: Monitor content safety and PII detection
- **Add Document Tab**: Submit new documents with format guide
- **Process Owners Tab**: Full CRUD operations for process owners

### Sidebar
- **FAQs**: Clickable frequently asked questions
- **Feedback Stats**: Personal feedback history and overall statistics
- **Admin Access**: Quick access to admin panel (admin users only)

## Troubleshooting

### Cannot connect to backend
- Ensure the FastAPI backend is running on `http://localhost:8000`
- Check the `VITE_API_BASE_URL` in `.env` file
- Verify CORS is properly configured on the backend

### Authentication fails
- Ensure you have a valid SSO access token
- Check token expiration
- Verify the backend `/sso/validate-token` endpoint is working

### Styling issues
- Clear browser cache
- Rebuild the application: `npm run build`
- Check for styled-components version compatibility

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Contributing

1. Create a feature branch
2. Make your changes
3. Test thoroughly
4. Submit a pull request

## License

Proprietary - GSK Internal Use Only

## Support

For issues or questions, contact the ARB Team.
